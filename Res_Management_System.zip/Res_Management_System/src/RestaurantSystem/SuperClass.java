/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RestaurantSystem;
 
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class SuperClass {
     public double ChickenBurger;
    public double BeefRoll;
    public double Pizza;
    public double ChickenTikka;
    public double ChickenKarahi;
    
    public double ColdDrink;
    public double MilkShake;
    public double Coffee;
    public double Tea;
    public double Juice;
    
    public double Meals;
    public double Drinks;
    public double Total;
    
    public double AllTotal;
    
    public double GetAmount(){
        Meals = ChickenBurger + BeefRoll + Pizza + ChickenTikka + ChickenKarahi;
        Drinks = ColdDrink + MilkShake + Coffee + Tea + Juice;
         Total = Meals + Drinks;
         AllTotal = Total;
         return AllTotal;
    }
    
    private JFrame frame;
    
    public void iExistSystem(){
        frame = new JFrame("Exist");
        
        if(JOptionPane.showConfirmDialog(frame, "Confirm if you want to exist","Restaurant Managment System",
            JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION){
            System.exit(0);
        }
    }
    
    
    //============================Price==============================
    
    public double pChickenBurger = 180;
    public double pBeefRoll = 120;
    public double pPizza = 800;
    public double pChickenTikka = 160;
    public double pChickenKarahi = 950;
    
    public double pColdDrink = 50;
    public double pMilkShake = 120;
    public double pCoffee = 150;
    public double pTea = 60;
    public double pJuice = 80;
    
    
    //================================================================
    
    public double mcTax = 0.13;
    
    public double cFindTax(double cAmount){
        double FindTax =  (cAmount * mcTax);
        return FindTax;
    }
}


